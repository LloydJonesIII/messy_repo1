# Notes and To-Do:
- Refactor the data cleaning code in demo_notebook.ipynb.
- Modularize repeated plotting routines.
- Check the source of missing values in data.csv.
- Remove any redundant or debugging print statements.
- Document functions and expected inputs/outputs.
