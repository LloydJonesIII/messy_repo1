# Basic Data Visualization & data processing Package
two column data visualization
Mean & Standard Deviation analysis on a column